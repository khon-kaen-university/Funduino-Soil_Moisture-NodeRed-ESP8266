/*
 * Implementation is in BLEStream.h to avoid linker issues.
 */
